export interface City {
  name: string;
  country: string;
  timezone: string;
}
